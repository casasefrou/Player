@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.mehditv.player

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.util.UUID

// ---------- Focus helpers (remote control friendly) ----------

@Composable
fun Modifier.focusRing(shape: Shape = RoundedCornerShape(12.dp)): Modifier {
    var focused by remember { mutableStateOf(false) }
    return this
        .onFocusChanged { focused = it.hasFocus }
        .then(if (focused) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, shape) else Modifier)
}

@Composable
fun Modifier.tvItem(shape: Shape, onClick: () -> Unit, onLongClick: (() -> Unit)? = null): Modifier {
    var focused by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    return this
        .clip(shape)
        .background(if (focused) cs.surfaceVariant else cs.surface)
        .onFocusChanged { focused = it.hasFocus }
        .combinedClickable(onClick = onClick, onLongClick = onLongClick)
        .then(if (focused) Modifier.border(2.dp, cs.primary, shape) else Modifier)
}

@Composable
private fun CenterBox(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center, content = content)
}

// ---------- Home ----------

@Composable
fun HomeScreen(vm: AppViewModel) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    var showAdd by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Playlist?>(null) }
    LaunchedEffect(Unit) { vm.checkUpdate() }

    Column(Modifier.fillMaxSize().background(cs.background).padding(horizontal = 24.dp, vertical = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(cs.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.PlayArrow, null, tint = cs.primary, modifier = Modifier.size(32.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.app_name),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    stringResource(R.string.tagline),
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
            if (vm.playlists.isNotEmpty()) AddButton { showAdd = true }
        }

        vm.update?.let { info ->
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(cs.primaryContainer).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    stringResource(R.string.update_available, info.versionName),
                    Modifier.weight(1f),
                    color = cs.onPrimaryContainer
                )
                TextButton(
                    onClick = {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(info.apkUrl))) }
                    },
                    modifier = Modifier.focusRing(CircleShape)
                ) { Text(stringResource(R.string.update_now)) }
            }
        }

        if (vm.playlists.isEmpty()) {
            Column(
                Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(stringResource(R.string.no_playlists), style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text(
                    stringResource(R.string.no_playlists_hint),
                    color = cs.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(20.dp))
                AddButton { showAdd = true }
            }
        } else {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                items(vm.playlists, key = { it.id }) { p ->
                    PlaylistRow(p, onOpen = { vm.openPlaylist(p) }, onDelete = { toDelete = p })
                }
            }
        }

        Text(
            stringResource(R.string.disclaimer),
            style = MaterialTheme.typography.labelSmall,
            color = cs.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
    }

    if (showAdd) {
        AddPlaylistDialog(onDismiss = { showAdd = false }, onSave = { vm.addPlaylist(it); showAdd = false })
    }
    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            containerColor = cs.surface,
            title = { Text(p.name) },
            text = { Text(stringResource(R.string.delete_confirm)) },
            confirmButton = {
                TextButton(onClick = { vm.removePlaylist(p); toDelete = null }) {
                    Text(stringResource(R.string.delete), color = cs.error)
                }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
private fun AddButton(onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Button(
        onClick = onClick,
        modifier = Modifier.focusRing(CircleShape),
        colors = ButtonDefaults.buttonColors(containerColor = cs.primary, contentColor = cs.onPrimary)
    ) {
        Icon(Icons.Default.Add, null, Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(stringResource(R.string.add_playlist))
    }
}

private fun subtitle(p: Playlist): String {
    val raw = if (p.type == PlaylistType.M3U) p.url else p.server
    val host = runCatching { Uri.parse(if (raw.contains("://")) raw else "http://$raw").host }.getOrNull() ?: raw
    return (if (p.type == PlaylistType.M3U) "M3U" else "Xtream") + " • " + host
}

@Composable
private fun PlaylistRow(p: Playlist, onOpen: () -> Unit, onDelete: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().tvItem(RoundedCornerShape(16.dp), onClick = onOpen).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(cs.primaryContainer),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.PlayArrow, null, tint = cs.primary) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(p.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                subtitle(p),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Default.Delete, stringResource(R.string.delete), tint = cs.onSurfaceVariant)
        }
    }
}

@Composable
private fun Field(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    password: Boolean = false,
    keyboard: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard)
    )
}

@Composable
private fun AddPlaylistDialog(onDismiss: () -> Unit, onSave: (Playlist) -> Unit) {
    var type by remember { mutableStateOf(PlaylistType.M3U) }
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var server by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val defaultName = stringResource(R.string.default_name)
    val valid = if (type == PlaylistType.M3U) url.isNotBlank()
    else server.isNotBlank() && user.isNotBlank() && pass.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(stringResource(R.string.add_playlist)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = type == PlaylistType.M3U,
                        onClick = { type = PlaylistType.M3U },
                        label = { Text(stringResource(R.string.type_m3u)) },
                        modifier = Modifier.focusRing(RoundedCornerShape(8.dp))
                    )
                    FilterChip(
                        selected = type == PlaylistType.XTREAM,
                        onClick = { type = PlaylistType.XTREAM },
                        label = { Text(stringResource(R.string.type_xtream)) },
                        modifier = Modifier.focusRing(RoundedCornerShape(8.dp))
                    )
                }
                Field(name, { name = it }, stringResource(R.string.field_name))
                if (type == PlaylistType.M3U) {
                    Field(url, { url = it }, stringResource(R.string.field_m3u_url), keyboard = KeyboardType.Uri)
                } else {
                    Field(server, { server = it }, stringResource(R.string.field_server), keyboard = KeyboardType.Uri)
                    Field(user, { user = it }, stringResource(R.string.field_username))
                    Field(pass, { pass = it }, stringResource(R.string.field_password), password = true)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = {
                    onSave(
                        Playlist(
                            id = UUID.randomUUID().toString(),
                            name = name.ifBlank { defaultName },
                            type = type,
                            url = url.trim(),
                            server = server.trim(),
                            username = user.trim(),
                            password = pass.trim()
                        )
                    )
                }
            ) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

// ---------- Channels ----------

@Composable
fun ChannelsScreen(vm: AppViewModel) {
    val cs = MaterialTheme.colorScheme
    val wide = LocalConfiguration.current.screenWidthDp >= 700
    val state = vm.state

    Column(Modifier.fillMaxSize().background(cs.background).padding(horizontal = 20.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.back() }, modifier = Modifier.focusRing(CircleShape)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back))
            }
            Text(
                vm.current?.name.orEmpty(),
                style = MaterialTheme.typography.titleLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            IconButton(onClick = { vm.reload() }, modifier = Modifier.focusRing(CircleShape)) {
                Icon(Icons.Default.Refresh, stringResource(R.string.retry))
            }
        }
        when (state) {
            is LoadState.Loading -> CenterBox(Modifier.weight(1f)) { CircularProgressIndicator(color = cs.primary) }
            is LoadState.Error -> CenterBox(Modifier.weight(1f)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(stringResource(R.string.load_failed), style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(state.message, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { vm.reload() }, modifier = Modifier.focusRing(CircleShape)) {
                        Text(stringResource(R.string.retry))
                    }
                }
            }
            is LoadState.Ready -> ChannelContent(vm, state.channels, wide)
        }
    }
}

@Composable
private fun tabLabel(t: Tab): String = when (t) {
    Tab.ALL -> stringResource(R.string.tab_all)
    Tab.LIVE -> stringResource(R.string.tab_live)
    Tab.MOVIES -> stringResource(R.string.tab_movies)
    Tab.FAVORITES -> stringResource(R.string.tab_fav)
}

@Composable
private fun ColumnScope.ChannelContent(vm: AppViewModel, all: List<Channel>, wide: Boolean) {
    val cs = MaterialTheme.colorScheme

    val hasMovies = remember(all) { all.any { it.section == Section.MOVIES } }
    val tabs = remember(hasMovies) {
        if (hasMovies) listOf(Tab.ALL, Tab.LIVE, Tab.MOVIES, Tab.FAVORITES) else listOf(Tab.ALL, Tab.FAVORITES)
    }
    val tabbed = remember(all, vm.tab, vm.favorites) {
        when (vm.tab) {
            Tab.ALL -> all
            Tab.LIVE -> all.filter { it.section == Section.LIVE }
            Tab.MOVIES -> all.filter { it.section == Section.MOVIES }
            Tab.FAVORITES -> all.filter { it.url in vm.favorites }
        }
    }
    val groups = remember(tabbed) { tabbed.map { it.group }.distinct().sorted() }
    val shown = remember(tabbed, vm.group, vm.query) {
        val q = vm.query.trim()
        tabbed.filter { (vm.group == null || it.group == vm.group) && (q.isEmpty() || it.name.contains(q, ignoreCase = true)) }
    }

    OutlinedTextField(
        value = vm.query,
        onValueChange = { vm.setQuery(it) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        placeholder = { Text(stringResource(R.string.search)) },
        leadingIcon = { Icon(Icons.Default.Search, null) },
        trailingIcon = {
            if (vm.query.isNotEmpty()) {
                IconButton(onClick = { vm.setQuery("") }) { Icon(Icons.Default.Close, null) }
            }
        }
    )

    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        tabs.forEach { t ->
            FilterChip(
                selected = vm.tab == t,
                onClick = { vm.setTab(t) },
                label = { Text(tabLabel(t)) },
                modifier = Modifier.focusRing(RoundedCornerShape(8.dp))
            )
        }
        Text(
            stringResource(R.string.channels_count, shown.size),
            color = cs.onSurfaceVariant,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.align(Alignment.CenterVertically).padding(start = 8.dp)
        )
    }

    if (wide) {
        Row(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(Modifier.width(240.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                item { GroupItem(stringResource(R.string.all_groups), vm.group == null) { vm.setGroup(null) } }
                items(groups) { g -> GroupItem(g, vm.group == g) { vm.setGroup(g) } }
            }
            Spacer(Modifier.width(16.dp))
            ChannelList(vm, shown, Modifier.weight(1f).fillMaxSize())
        }
    } else {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            item {
                FilterChip(
                    selected = vm.group == null,
                    onClick = { vm.setGroup(null) },
                    label = { Text(stringResource(R.string.all_groups)) },
                    modifier = Modifier.focusRing(RoundedCornerShape(8.dp))
                )
            }
            items(groups) { g ->
                FilterChip(
                    selected = vm.group == g,
                    onClick = { vm.setGroup(g) },
                    label = { Text(g, maxLines = 1) },
                    modifier = Modifier.focusRing(RoundedCornerShape(8.dp))
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        ChannelList(vm, shown, Modifier.weight(1f).fillMaxWidth())
    }
}

@Composable
private fun GroupItem(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Text(
        label,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        color = if (selected) cs.primary else cs.onSurface,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        modifier = Modifier.fillMaxWidth().tvItem(RoundedCornerShape(12.dp), onClick = onClick).padding(12.dp)
    )
}

@Composable
private fun ChannelList(vm: AppViewModel, shown: List<Channel>, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    if (shown.isEmpty()) {
        CenterBox(modifier) {
            Text(stringResource(R.string.empty), color = cs.onSurfaceVariant)
        }
        return
    }
    Column(modifier) {
        Text(
            stringResource(R.string.fav_hint),
            style = MaterialTheme.typography.labelSmall,
            color = cs.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = vm.channelListState,
            verticalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            itemsIndexed(shown) { i, ch ->
                ChannelRow(
                    ch,
                    fav = ch.url in vm.favorites,
                    onClick = { vm.play(shown, i) },
                    onLong = { vm.toggleFav(ch) }
                )
            }
        }
    }
}

@Composable
private fun ChannelRow(ch: Channel, fav: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth()
            .tvItem(RoundedCornerShape(14.dp), onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (ch.logo.isBlank()) {
                Icon(Icons.Default.PlayArrow, null, tint = cs.onSurfaceVariant)
            } else {
                AsyncImage(
                    model = ch.logo,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(4.dp)
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(ch.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                ch.group,
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (fav) Icon(Icons.Default.Star, null, tint = cs.secondary)
    }
}
