package com.mehditv.player

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Storage(context: Context) {
    private val prefs = context.getSharedPreferences("mehditv", Context.MODE_PRIVATE)

    fun loadPlaylists(): List<Playlist> = try {
        val arr = JSONArray(prefs.getString("playlists", "[]") ?: "[]")
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Playlist(
                id = o.getString("id"),
                name = o.getString("name"),
                type = PlaylistType.valueOf(o.getString("type")),
                url = o.optString("url"),
                server = o.optString("server"),
                username = o.optString("username"),
                password = o.optString("password")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun savePlaylists(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id).put("name", p.name).put("type", p.type.name)
                    .put("url", p.url).put("server", p.server)
                    .put("username", p.username).put("password", p.password)
            )
        }
        prefs.edit().putString("playlists", arr.toString()).apply()
    }

    fun loadFavorites(playlistId: String): Set<String> =
        prefs.getStringSet("fav_$playlistId", emptySet())?.toSet() ?: emptySet()

    fun saveFavorites(playlistId: String, favs: Set<String>) {
        prefs.edit().putStringSet("fav_$playlistId", HashSet(favs)).apply()
    }
}
