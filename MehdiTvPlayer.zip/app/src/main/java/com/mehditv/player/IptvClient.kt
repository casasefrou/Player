package com.mehditv.player

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object IptvClient {

    fun load(p: Playlist): List<Channel> {
        val list = if (p.type == PlaylistType.M3U) parseM3u(fetch(withScheme(p.url))) else loadXtream(p)
        if (list.isEmpty()) throw IOException("Empty playlist")
        return list
    }

    private fun withScheme(u: String): String {
        val t = u.trim()
        return if (t.startsWith("http://") || t.startsWith("https://")) t else "http://$t"
    }

    class HttpStatusException(val code: Int) : IOException("HTTP $code")

    fun fetch(startUrl: String): String {
        val agents = listOf(Constants.USER_AGENT) + Constants.FALLBACK_AGENTS
        var last: IOException? = null
        for (ua in agents) {
            try {
                return fetchOnce(startUrl, ua)
            } catch (e: HttpStatusException) {
                last = e // server rejected this identity; try the next one
            }
        }
        throw last ?: IOException("Request failed")
    }

    private fun fetchOnce(startUrl: String, userAgent: String): String {
        var current = startUrl
        for (i in 0..5) {
            val conn = URL(current).openConnection() as HttpURLConnection
            conn.connectTimeout = 20000
            conn.readTimeout = 60000
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", userAgent)
            conn.setRequestProperty("Accept", "*/*")
            try {
                val code = conn.responseCode
                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location") ?: throw IOException("Bad redirect")
                    current = URL(URL(current), loc).toString()
                    continue
                }
                if (code !in 200..299) throw HttpStatusException(code)
                return conn.inputStream.bufferedReader().use { it.readText() }
            } finally {
                conn.disconnect()
            }
        }
        throw IOException("Too many redirects")
    }

    // ---------- M3U ----------
    private val attrRegex = Regex("""([\w-]+)="([^"]*)"""")

    fun parseM3u(text: String): List<Channel> {
        val out = ArrayList<Channel>()
        var name = ""
        var logo = ""
        var group = ""
        for (raw in text.lineSequence()) {
            val line = raw.trim().removePrefix("\uFEFF")
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF")) {
                val attrs = attrRegex.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                logo = attrs["tvg-logo"] ?: ""
                group = attrs["group-title"] ?: ""
                val idx = line.lastIndexOf(',')
                name = if (idx >= 0) line.substring(idx + 1).trim() else ""
                if (name.isEmpty()) name = attrs["tvg-name"] ?: ""
            } else if (line.startsWith("#EXTGRP:")) {
                group = line.removePrefix("#EXTGRP:").trim()
            } else if (!line.startsWith("#")) {
                val section = if (line.contains("/movie/")) Section.MOVIES else Section.LIVE
                out.add(Channel(name.ifEmpty { line }, line, logo, group.ifEmpty { "Other" }, section))
                name = ""; logo = ""; group = ""
            }
        }
        return out
    }

    // ---------- Xtream Codes ----------
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun JSONObject.str(key: String): String = if (isNull(key)) "" else optString(key)

    private fun jsonArray(text: String): JSONArray = try {
        JSONArray(text)
    } catch (e: JSONException) {
        throw IOException("Login failed or invalid server")
    }

    private fun categories(url: String): Map<String, String> = try {
        val arr = JSONArray(fetch(url))
        val map = HashMap<String, String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            map[o.str("category_id")] = o.str("category_name")
        }
        map
    } catch (e: Exception) {
        emptyMap()
    }

    private fun loadXtream(p: Playlist): List<Channel> = try {
        loadXtreamApi(p)
    } catch (e: IOException) {
        // Fallback: some panels block the API but allow the classic get.php playlist
        try {
            val base = withScheme(p.server).trimEnd('/')
            val list = parseM3u(
                fetch("$base/get.php?username=${enc(p.username.trim())}&password=${enc(p.password.trim())}&type=m3u_plus&output=ts")
            )
            if (list.isEmpty()) throw e
            list
        } catch (e2: IOException) {
            throw e
        }
    }

    private fun loadXtreamApi(p: Playlist): List<Channel> {
        val base = withScheme(p.server).trimEnd('/')
        val user = p.username.trim()
        val pass = p.password.trim()
        val api = "$base/player_api.php?username=${enc(user)}&password=${enc(pass)}"
        val out = ArrayList<Channel>()

        val liveCats = categories("$api&action=get_live_categories")
        val live = jsonArray(fetch("$api&action=get_live_streams"))
        for (i in 0 until live.length()) {
            val o = live.getJSONObject(i)
            val id = o.str("stream_id")
            out.add(
                Channel(
                    name = o.str("name"),
                    url = "$base/live/$user/$pass/$id.m3u8",
                    logo = o.str("stream_icon"),
                    group = liveCats[o.str("category_id")] ?: "Live",
                    section = Section.LIVE
                )
            )
        }

        try {
            val vodCats = categories("$api&action=get_vod_categories")
            val vod = JSONArray(fetch("$api&action=get_vod_streams"))
            for (i in 0 until vod.length()) {
                val o = vod.getJSONObject(i)
                val id = o.str("stream_id")
                val ext = o.str("container_extension").ifEmpty { "mp4" }
                out.add(
                    Channel(
                        name = o.str("name"),
                        url = "$base/movie/$user/$pass/$id.$ext",
                        logo = o.str("stream_icon"),
                        group = vodCats[o.str("category_id")] ?: "Movies",
                        section = Section.MOVIES
                    )
                )
            }
        } catch (e: Exception) {
            // Movies are optional; ignore failures
        }
        return out
    }
}
