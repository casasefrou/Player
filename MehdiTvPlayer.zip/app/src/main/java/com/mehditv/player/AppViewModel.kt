package com.mehditv.player

import android.app.Application
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val storage = Storage(app)

    val playlists = mutableStateListOf<Playlist>()
    var screen by mutableStateOf(Screen.HOME)
        private set
    var current by mutableStateOf<Playlist?>(null)
        private set
    var state by mutableStateOf<LoadState>(LoadState.Loading)
        private set
    var favorites by mutableStateOf<Set<String>>(emptySet())
        private set
    var query by mutableStateOf("")
        private set
    var tab by mutableStateOf(Tab.ALL)
        private set
    var group by mutableStateOf<String?>(null)
        private set
    var playQueue by mutableStateOf<List<Channel>>(emptyList())
        private set
    var playIndex by mutableIntStateOf(0)
        private set
    var update by mutableStateOf<UpdateInfo?>(null)
        private set

    val channelListState = LazyListState()
    private var job: Job? = null

    init {
        playlists.addAll(storage.loadPlaylists())
    }

    fun addPlaylist(p: Playlist) {
        playlists.add(p)
        storage.savePlaylists(playlists)
    }

    fun removePlaylist(p: Playlist) {
        playlists.remove(p)
        storage.savePlaylists(playlists)
    }

    fun openPlaylist(p: Playlist) {
        current = p
        favorites = storage.loadFavorites(p.id)
        query = ""
        tab = Tab.ALL
        group = null
        screen = Screen.CHANNELS
        loadCurrent()
    }

    fun reload() = loadCurrent()

    private fun loadCurrent() {
        val p = current ?: return
        job?.cancel()
        state = LoadState.Loading
        job = viewModelScope.launch {
            state = try {
                LoadState.Ready(withContext(Dispatchers.IO) { IptvClient.load(p) })
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                LoadState.Error(e.message ?: e.javaClass.simpleName)
            }
        }
    }

    fun setQuery(q: String) { query = q; resetScroll() }
    fun setTab(t: Tab) { tab = t; group = null; resetScroll() }
    fun setGroup(g: String?) { group = g; resetScroll() }
    private fun resetScroll() { viewModelScope.launch { channelListState.scrollToItem(0) } }

    fun toggleFav(ch: Channel) {
        val p = current ?: return
        favorites = if (ch.url in favorites) favorites - ch.url else favorites + ch.url
        storage.saveFavorites(p.id, favorites)
    }

    fun play(list: List<Channel>, index: Int) {
        playQueue = list
        playIndex = index
        screen = Screen.PLAYER
    }

    fun back() {
        when (screen) {
            Screen.PLAYER -> screen = Screen.CHANNELS
            Screen.CHANNELS -> { job?.cancel(); screen = Screen.HOME }
            Screen.HOME -> {}
        }
    }

    fun checkUpdate() {
        if (Constants.UPDATE_JSON_URL.isBlank()) return
        viewModelScope.launch {
            update = withContext(Dispatchers.IO) {
                runCatching {
                    val o = JSONObject(IptvClient.fetch(Constants.UPDATE_JSON_URL))
                    if (o.getInt("versionCode") > BuildConfig.VERSION_CODE)
                        UpdateInfo(o.optString("versionName"), o.getString("apkUrl"))
                    else null
                }.getOrNull()
            }
        }
    }
}
