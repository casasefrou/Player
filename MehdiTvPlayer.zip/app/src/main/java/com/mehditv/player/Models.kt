package com.mehditv.player

enum class PlaylistType { M3U, XTREAM }
enum class Section { LIVE, MOVIES }
enum class Tab { ALL, LIVE, MOVIES, FAVORITES }
enum class Screen { HOME, CHANNELS, PLAYER }

data class Playlist(
    val id: String,
    val name: String,
    val type: PlaylistType,
    val url: String = "",
    val server: String = "",
    val username: String = "",
    val password: String = ""
)

data class Channel(
    val name: String,
    val url: String,
    val logo: String = "",
    val group: String = "",
    val section: Section = Section.LIVE
)

data class UpdateInfo(val versionName: String, val apkUrl: String)

sealed interface LoadState {
    object Loading : LoadState
    data class Error(val message: String) : LoadState
    data class Ready(val channels: List<Channel>) : LoadState
}

object Constants {
    // Put the direct link of your update.json here (leave empty to disable update checks)
    const val UPDATE_JSON_URL = ""
    const val USER_AGENT = "MehdiTvPlayer/1.0"
}
