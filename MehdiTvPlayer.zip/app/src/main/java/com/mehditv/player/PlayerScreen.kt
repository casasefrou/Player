@file:OptIn(UnstableApi::class)

package com.mehditv.player

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

@Composable
fun PlayerScreen(vm: AppViewModel) {
    val context = LocalContext.current
    val view = LocalView.current
    val queue = remember { vm.playQueue }
    val startIndex = remember { vm.playIndex }

    var title by remember { mutableStateOf(queue.getOrNull(startIndex)?.name.orEmpty()) }
    var showTitle by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    val retried = remember { mutableSetOf<String>() }

    val exo = remember {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(Constants.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(30_000)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(http))
            .build()
    }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                title = mediaItem?.mediaMetadata?.title?.toString().orEmpty()
                error = false
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) error = false
            }

            override fun onPlayerError(e: PlaybackException) {
                val item = exo.currentMediaItem
                val uri = item?.localConfiguration?.uri?.toString()
                if (item != null && uri != null && uri.endsWith(".m3u8") && uri.contains("/live/") && retried.add(uri)) {
                    // Xtream fallback: try the .ts stream if .m3u8 fails
                    exo.replaceMediaItem(
                        exo.currentMediaItemIndex,
                        item.buildUpon().setUri(uri.removeSuffix(".m3u8") + ".ts").build()
                    )
                    exo.prepare()
                    exo.play()
                    return
                }
                error = true
            }
        }
        exo.addListener(listener)

        val start = (startIndex - 250).coerceAtLeast(0)
        val end = (startIndex + 250).coerceAtMost(queue.size)
        val items = queue.subList(start, end).map {
            MediaItem.Builder()
                .setUri(it.url)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(it.name).build())
                .build()
        }
        exo.setMediaItems(items, startIndex - start, 0L)
        exo.prepare()
        exo.playWhenReady = true

        onDispose {
            exo.removeListener(listener)
            exo.release()
        }
    }

    // Pause when the app goes to background
    DisposableEffect(exo) {
        val lifecycle = (context as? LifecycleOwner)?.lifecycle
        val observer = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) exo.pause() }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }

    // Immersive mode
    DisposableEffect(Unit) {
        val window = (context as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    LaunchedEffect(title) {
        showTitle = true
        delay(3500)
        showTitle = false
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onPreviewKeyEvent { e ->
                if (e.type == KeyEventType.KeyDown) {
                    when (e.key) {
                        Key.ChannelUp, Key.PageUp -> { exo.seekToNextMediaItem(); true }
                        Key.ChannelDown, Key.PageDown -> { exo.seekToPreviousMediaItem(); true }
                        else -> false
                    }
                } else false
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exo
                    useController = true
                    controllerShowTimeoutMs = 4000
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    keepScreenOn = true
                    isFocusable = true
                    requestFocus()
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (showTitle && title.isNotEmpty()) {
            Text(
                title,
                color = Color.White,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(16.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0x99000000))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            )
        }

        if (error) {
            Text(
                stringResource(R.string.playback_error),
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xCC16202A))
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            )
        }
    }
}
