package com.mehditv.player

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Bg = Color(0xFF0E151C)
private val SurfaceCol = Color(0xFF16202A)
private val SurfaceHigh = Color(0xFF212F3C)
private val Sage = Color(0xFF8FC1BC)
private val Periwinkle = Color(0xFFA9B8D6)
private val TextMain = Color(0xFFE3EAEF)
private val TextMuted = Color(0xFF8A9AA8)
private val SoftRed = Color(0xFFD99A9A)

@Composable
fun MehdiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Sage,
            onPrimary = Bg,
            primaryContainer = Color(0xFF223B3B),
            onPrimaryContainer = TextMain,
            secondary = Periwinkle,
            onSecondary = Bg,
            background = Bg,
            onBackground = TextMain,
            surface = SurfaceCol,
            onSurface = TextMain,
            surfaceVariant = SurfaceHigh,
            onSurfaceVariant = TextMuted,
            error = SoftRed
        ),
        content = content
    )
}
