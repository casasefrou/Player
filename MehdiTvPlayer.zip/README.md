# MehdiTv Player

مشغّل M3U و Xtream Codes فارغ تماماً من أي قنوات أو محتوى.

## البناء السحابي (بدون Android Studio)
1. أنشئ مستودعاً عاماً (Public) على GitHub.
2. ارفع كل ملفات هذا المجلد، مع المجلد المخفي `.github/workflows/build.yml`.
3. من تبويب Actions شغّل Build APK، أو يعمل تلقائياً عند كل رفع.
4. الرابط الثابت للتحميل:
   https://github.com/USERNAME/REPO/releases/latest/download/MehdiTvPlayer.apk

## التوقيع الدائم (مهم للتحديثات)
أضف في Settings > Secrets > Actions:
KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD
بدونها يُوقَّع التطبيق بمفتاح تجريبي ولن يتحدّث فوق النسخة القديمة.

## التحديث التلقائي
ضع رابط update.json في Constants.kt (UPDATE_JSON_URL).
